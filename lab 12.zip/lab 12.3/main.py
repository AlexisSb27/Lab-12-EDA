class BSTNode:
    def __init__(self, data):
        self.left = None
        self.right = None
        self.data = data

def insertNode(root, node):
    if root is None:
        root = node
    else:
        if root.data > node.data:
            if root.left is None:
                root.left = node
            else:
                insertNode(root.left, node)
        else:
            if root.right is None:
                root.right = node
            else:
                insertNode(root.right, node)

def deleteNodeWithTwoChildren(root, key):
    if root is None:
        return None

    if key < root.data:
        root.left = deleteNodeWithTwoChildren(root.left, key)
    elif key > root.data:
        root.right = deleteNodeWithTwoChildren(root.right, key)
    else:
        if root.left is None:
            return root.right
        elif root.right is None:
            return root.left
        else:
            successor = findMin(root.right)
            root.data = successor.data
            root.right = deleteNodeWithTwoChildren(root.right, successor.data)

    return root

def findMin(root):
    currentNode = root
    if currentNode.left is None:
        return currentNode
    else:
        return findMin(currentNode.left)

root = BSTNode(15)
insertNode(root, BSTNode(11))
insertNode(root, BSTNode(18))
insertNode(root, BSTNode(9))
insertNode(root, BSTNode(13))

root = deleteNodeWithTwoChildren(root, 15)
root = deleteNodeWithTwoChildren(root, 11)
root = deleteNodeWithTwoChildren(root, 18)
root = deleteNodeWithTwoChildren(root, 9)
root = deleteNodeWithTwoChildren(root, 13)

def printBST(root):
    if root:
        printBST(root.left)
        print(root.data)
        printBST(root.right)

printBST(root)
