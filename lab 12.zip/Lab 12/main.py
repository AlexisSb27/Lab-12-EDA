import random
import time

class BSTNode:
    def __init__(self, data):
        self.left = None
        self.right = None
        self.data = data

def insertNode(root, node):
    if root is None:
        root = node
    else:
        if root.data > node.data:
            if root.left is None:
                root.left = node
            else:
                insertNode(root.left, node)
        else:
            if root.right is None:
                root.right = node
            else:
                insertNode(root.right, node)

def searchNode(root, key):
    if root is None or root.data == key:
        return root is not None

    if root.data < key:
        return searchNode(root.right, key)
    else:
        return searchNode(root.left, key)

def generate_random_numbers(count, min_val, max_val):
    return [random.randint(min_val, max_val) for _ in range(count)]

def write_numbers_to_file(numbers, filename):
    with open(filename, 'w') as file:
        for number in numbers:
            file.write(str(number) + '\n')

def read_numbers_from_file(filename):
    numbers = []
    with open(filename, 'r') as file:
        for line in file:
            number = int(line.strip())
            numbers.append(number)
    return numbers

def buildBSTFromList(numbers):
    root = None
    for number in numbers:
        if root is None:
            root = BSTNode(number)
        else:
            insertNode(root, BSTNode(number))
    return root

random_numbers = generate_random_numbers(1000, 1, 50000)

write_numbers_to_file(random_numbers, 'numbers.txt')

numbers_from_file = read_numbers_from_file('numbers.txt')

bst_root = buildBSTFromList(numbers_from_file)

start_time = time.time()
search_number1 = random.choice(numbers_from_file)
is_present1 = searchNode(bst_root, search_number1)
end_time = time.time()
search_time1 = end_time - start_time

start_time = time.time()
search_number2 = random.choice(numbers_from_file)
is_present2 = searchNode(bst_root, search_number2)
end_time = time.time()
search_time2 = end_time - start_time

start_time = time.time()
search_number3 = random.choice(numbers_from_file)
is_present3 = searchNode(bst_root, search_number3)
end_time = time.time()
search_time3 = end_time - start_time

print(f"Búsqueda 1: Número {search_number1} {'encontrado' if is_present1 else 'no encontrado'}. Tiempo: {search_time1} segundos.")
print(f"Búsqueda 2: Número {search_number2} {'encontrado' if is_present2 else 'no encontrado'}. Tiempo: {search_time2} segundos.")
print(f"Búsqueda 3: Número {search_number3} {'encontrado' if is_present3 else 'no encontrado'}. Tiempo: {search_time3} segundos.")
