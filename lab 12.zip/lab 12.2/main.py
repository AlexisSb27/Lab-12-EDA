class BSTNode:
    def __init__(self, data):
        self.left = None
        self.right = None
        self.data = data

def insertNode(root, node):
    if root is None:
        root = node
    else:
        if root.data > node.data:
            if root.left is None:
                root.left = node
            else:
                insertNode(root.left, node)
        else:
            if root.right is None:
                root.right = node
            else:
                insertNode(root.right, node)

def deleteNodeWithOneChild(root, key):
    if root is None:
        return None

    if key < root.data:
        root.left = deleteNodeWithOneChild(root.left, key)
    elif key > root.data:
        root.right = deleteNodeWithOneChild(root.right, key)
    else:
        if root.left is None:
            return root.right
        elif root.right is None:
            return root.left

    return root

root = BSTNode(15)
insertNode(root, BSTNode(11))
insertNode(root, BSTNode(18))
insertNode(root, BSTNode(9))
insertNode(root, BSTNode(13))
insertNode(root, BSTNode(17))
insertNode(root, BSTNode(19))


root = deleteNodeWithOneChild(root, 17)

def printBST(root):
    if root:
        printBST(root.left)
        print(root.data)
        printBST(root.right)

printBST(root)
